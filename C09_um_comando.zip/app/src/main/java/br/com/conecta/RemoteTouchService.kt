package br.com.conecta

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Serviço de acessibilidade que injeta gestos autorizados na tela.
 *
 * Só executa gestos quando existe uma instância conectada E o aparelho está
 * numa sessão consentida (o MainActivity só envia eventos enquanto o canal de
 * controle WebRTC estiver aberto e a sessão aprovada). Não coleta conteúdo de
 * janelas.
 */
class RemoteTouchService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não coleta conteúdo de janelas.
    }

    override fun onInterrupt() {
        // Interrompe qualquer operação em andamento.
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    /**
     * Injeta um toque/arrasto autorizado. A lista usa coordenadas normalizadas
     * (0..1) relativas à tela do aparelho que compartilha.
     */
    fun performAuthorizedGesture(points: List<Pair<Float, Float>>, durationMs: Long): Boolean {
        if (points.isEmpty()) return false
        val size = screenSize()
        val path = Path()
        val first = points.first()
        path.moveTo(first.first * size.first, first.second * size.second)
        for (i in 1 until points.size) {
            path.lineTo(points[i].first * size.first, points[i].second * size.second)
        }
        if (points.size == 1) {
            // Um único ponto é interpretado como toque curto.
            path.lineTo(first.first * size.first + 1f, first.second * size.second + 1f)
        }
        val stroke = GestureDescription.StrokeDescription(
            path, 0L, durationMs.coerceIn(MIN_DURATION_MS, MAX_DURATION_MS)
        )
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun screenSize(): Pair<Float, Float> {
        val wm = getSystemService(WindowManager::class.java)
        val rect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.currentWindowMetrics.bounds
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }
        return Pair(rect.width().toFloat(), rect.height().toFloat())
    }

    companion object {
        @Volatile
        private var instance: RemoteTouchService? = null

        private const val MIN_DURATION_MS = 24L
        private const val MAX_DURATION_MS = 5000L

        /** O controle remoto só funciona se o serviço estiver ativado pelo usuário. */
        fun isEnabled(): Boolean = instance != null

        /** Retorna false se o serviço de acessibilidade não estiver ativado. */
        fun dispatch(points: List<Pair<Float, Float>>, durationMs: Long): Boolean =
            instance?.performAuthorizedGesture(points, durationMs) ?: false
    }
}