package br.com.conecta

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.graphics.Color
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputFilter
import android.text.InputType
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import java.net.URI
import java.nio.ByteBuffer

class MainActivity : Activity() {
    private val white = Color.WHITE
    private val gray = Color.LTGRAY
    private var ws: WebSocketClient? = null
    private var role = ""
    private var pin = ""
    private var approved = false
    private var remoteDescriptionSet = false
    private val pendingIce = mutableListOf<IceCandidate>()
    private var peer: PeerConnection? = null
    private var factory: PeerConnectionFactory? = null
    private var egl: EglBase? = null
    private var videoSource: VideoSource? = null
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var localTrack: VideoTrack? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var controlChannel: DataChannel? = null
    private var videoAspect = 16f / 9f
    private val touchPoints = mutableListOf<Pair<Float, Float>>()
    private var touchStartMs = 0L
    private var serverUrl = ""
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var remoteLabel: TextView
    private lateinit var pinView: TextView
    private lateinit var pinInput: EditText
    private lateinit var serverInput: EditText
    private val projectionRequest = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        showHome()
    }

    override fun onResume() {
        super.onResume()
        if (role == "host" && this::remoteLabel.isInitialized) remoteLabel.text = remoteLabelText()
    }

    private fun base(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(8), dp(18), dp(8)); setBackgroundColor(Color.BLACK)
        }
        root.addView(label("C09", 12, gray, true), lp())
        root.addView(label(title, 24, white, true), lp())
        root.addView(label(subtitle, 13, gray, false), lp())
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(5), dp(12), dp(5)); setBackgroundColor(Color.BLACK) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("Compartilhamento somente com autorização explícita.", 11, gray, false), lp())
        setContentView(root)
    }

    private fun showHome() {
        base("C09", "Compartilhamento de tela autorizado")
        serverInput = EditText(this).apply {
            hint = "Servidor seguro wss://..."; setHintTextColor(gray); setTextColor(white)
            textSize = 14f; inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true); setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(25,25,25))
        }
        content.addView(serverInput, lp())
        content.addView(label("Informe o endereço do servidor WebSocket seguro (WSS) hospedado para conectar os aparelhos.", 12, gray, false), lp())
        content.addView(btn("Compartilhar minha tela") {
            serverUrl = serverInput.text.toString().trim()
            if (!validServer()) return@btn
            role = "host"; connectSocket { send(JSONObject().put("type", "create")) }
        }, lpTop())
        content.addView(btn("Assistir tela de outro aparelho") {
            serverUrl = serverInput.text.toString().trim()
            if (!validServer()) return@btn
            showJoin()
        }, lpTop())
    }

    private fun validServer(): Boolean {
        if (!serverUrl.startsWith("wss://")) {
            Toast.makeText(this, "Use um servidor WebSocket seguro começando com wss://", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }

    private fun showJoin() {
        base("Conectar", "Digite o código mostrado no aparelho compartilhado")
        pinInput = EditText(this).apply {
            hint = "Código de 4 números"; setHintTextColor(gray); setTextColor(white); textSize = 22f
            gravity = Gravity.CENTER; inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(4)); setSingleLine(true)
            setBackgroundColor(Color.rgb(25,25,25))
        }
        content.addView(pinInput, lp())
        content.addView(btn("Conectar") {
            pin = pinInput.text.toString()
            if (!pin.matches(Regex("\\d{4}"))) { status("Digite um código de quatro números."); return@btn }
            role = "client"
            connectSocket { send(JSONObject().put("type", "join").put("pin", pin)) }
        }, lpTop())
        content.addView(btn("Voltar") { closeSession(); showHome() }, lpTop())
        status = label("Aguardando conexão.", 13, gray, false); content.addView(status, lpTop())
    }

    private fun showHost(pinCode: String) {
        base("Compartilhar tela", "Informe o código somente à pessoa autorizada")
        pinView = label(pinCode, 38, white, true).apply { gravity = Gravity.CENTER }
        content.addView(pinView, lp())
        status = label("Aguardando pedido de conexão…", 13, gray, false); content.addView(status, lp())
        content.addView(btn("Autorizar conexão e compartilhar") {
            if (!approved) send(JSONObject().put("type", "approve"))
        }, lpTop())
        remoteLabel = label(remoteLabelText(), 12, gray, false)
        content.addView(remoteLabel, lpTop())
        content.addView(btn(if (RemoteTouchService.isEnabled()) "Gerenciar controle remoto" else "Permitir controle remoto (Acessibilidade)") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (e: Exception) { Toast.makeText(this, "Abra Ajustes > Acessibilidade e ative o C09.", Toast.LENGTH_LONG).show() }
        }, lpTop())
        content.addView(btn("Desconectar") { closeSession(); showHome() }, lpTop())
    }

    private fun showViewer() {
        base("Tela compartilhada", "Toque para controlar o aparelho remoto")
        egl = egl ?: EglBase.create()
        remoteRenderer = SurfaceViewRenderer(this).apply {
            init(egl!!.eglBaseContext, null); setEnableHardwareScaler(true); setMirror(false)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
            setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { touchPoints.clear(); touchStartMs = System.currentTimeMillis(); addTouchPoint(v, ev) }
                    MotionEvent.ACTION_MOVE -> addTouchPoint(v, ev)
                    MotionEvent.ACTION_UP -> { addTouchPoint(v, ev); sendGesture() }
                    MotionEvent.ACTION_CANCEL -> touchPoints.clear()
                }
                true
            }
        }
        content.addView(remoteRenderer, LinearLayout.LayoutParams(-1, 0, 1f))
        status = label("Conectando vídeo…", 12, gray, false); content.addView(status, lp())
        content.addView(btn("Desconectar") { closeSession(); showHome() }, lpTop())
        initPeer()
    }

    private fun remoteLabelText() =
        if (RemoteTouchService.isEnabled()) "Controle remoto de toques: ativo." else "Controle remoto de toques: desativado."

    private fun connectSocket(afterConnect: () -> Unit) {
        status = if (::status.isInitialized) status else label("Conectando ao servidor…", 13, gray, false)
        try {
            ws?.close()
            ws = object : WebSocketClient(URI(serverUrl)) {
                override fun onOpen(handshakedata: ServerHandshake?) { runOnUiThread { afterConnect() } }
                override fun onMessage(message: String?) { if (message != null) runOnUiThread { handleSignal(JSONObject(message)) } }
                override fun onClose(code: Int, reason: String?, remote: Boolean) { runOnUiThread { if (approved) status("Conexão de sinalização encerrada.") } }
                override fun onError(ex: Exception?) { runOnUiThread { Toast.makeText(this@MainActivity, "Falha no servidor: ${ex?.message ?: "desconhecida"}", Toast.LENGTH_LONG).show() } }
            }
            ws!!.connect()
        } catch (e: Exception) {
            Toast.makeText(this, "Endereço do servidor inválido.", Toast.LENGTH_LONG).show()
        }
    }

    private fun send(obj: JSONObject) { try { ws?.send(obj.toString()) } catch (_: Exception) {} }

    private fun handleSignal(msg: JSONObject) {
        when (msg.optString("type")) {
            "created" -> { pin = msg.optString("pin"); showHost(pin) }
            "join_request" -> { if (::status.isInitialized) status("Pedido recebido. Confira com a pessoa antes de autorizar.") }
            "joined" -> { if (::status.isInitialized) status("Pedido enviado. Aguarde autorização no outro aparelho.") }
            "approved" -> {
                approved = true
                if (role == "host") {
                    status("Autorizado. O Android vai pedir permissão para capturar a tela.")
                    val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(mgr.createScreenCaptureIntent(), projectionRequest)
                } else { showViewer() }
            }
            "offer" -> { if (role == "client") receiveOffer(msg.optString("sdp")) }
            "answer" -> { if (role == "host") receiveAnswer(msg.optString("sdp")) }
            "ice" -> addIce(msg.optJSONObject("candidate"))
            "disconnected", "peer_disconnected", "expired" -> { status("A sessão foi encerrada.") }
            "error" -> Toast.makeText(this, "Servidor: ${msg.optString("message")}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest) {
            if (resultCode == RESULT_OK && data != null && role == "host" && approved) startScreenCapture(resultCode, data)
            else { status("Captura cancelada. Nenhuma tela foi compartilhada."); closeSession() }
        }
    }

    private fun initializeRtc() {
        if (factory != null) return
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions())
        egl = egl ?: EglBase.create()
        factory = PeerConnectionFactory.builder().setVideoEncoderFactory(DefaultVideoEncoderFactory(egl!!.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl!!.eglBaseContext)).createPeerConnectionFactory()
    }

    private fun initPeer() {
        initializeRtc()
        if (peer != null) return
        val iceServers = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        val config = PeerConnection.RTCConfiguration(iceServers).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        peer = factory!!.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) { runOnUiThread { if (state == PeerConnection.IceConnectionState.CONNECTED) status("Vídeo conectado.") } }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (candidate != null) send(JSONObject().put("type", "ice").put("candidate", JSONObject().put("sdpMid", candidate.sdpMid).put("sdpMLineIndex", candidate.sdpMLineIndex).put("candidate", candidate.sdp)))
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {}
            override fun onRemoveStream(stream: MediaStream?) {}
            override fun onDataChannel(channel: DataChannel?) { if (channel != null) attachControlChannel(channel) }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
                val track = receiver?.track() as? VideoTrack
                if (track != null) runOnUiThread { remoteRenderer?.let { track.addSink(it) } }
            }
            override fun onTrack(transceiver: RtpTransceiver?) {
                val track = transceiver?.receiver?.track() as? VideoTrack
                if (track != null) runOnUiThread { remoteRenderer?.let { track.addSink(it) } }
            }
        })
        if (role == "host") createControlChannel()
    }

    private fun createControlChannel() {
        val init = DataChannel.Init().apply { ordered = true }
        val channel = peer?.createDataChannel("c09-control", init) ?: return
        attachControlChannel(channel)
    }

    private fun attachControlChannel(channel: DataChannel) {
        controlChannel?.unregisterObserver()
        controlChannel = channel
        channel.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) {}
            override fun onStateChange() {
                if (channel.state() == DataChannel.State.OPEN && role == "host") {
                    val dm = resources.displayMetrics
                    val w = maxOf(dm.widthPixels, dm.heightPixels)
                    val h = minOf(dm.widthPixels, dm.heightPixels)
                    sendControl(JSONObject().put("type", "screen").put("width", w).put("height", h))
                }
            }
            override fun onMessage(buffer: DataChannel.Buffer) { handleControlMessage(buffer) }
        })
    }

    private fun sendControl(obj: JSONObject) {
        val channel = controlChannel ?: return
        if (channel.state() != DataChannel.State.OPEN) return
        try {
            channel.send(DataChannel.Buffer(ByteBuffer.wrap(obj.toString().toByteArray(Charsets.UTF_8)), false))
        } catch (_: Exception) {}
    }

    private fun handleControlMessage(buffer: DataChannel.Buffer) {
        val bytes = ByteArray(buffer.data.remaining())
        buffer.data.get(bytes)
        val text = String(bytes, Charsets.UTF_8)
        runOnUiThread { try { handleControlSignal(JSONObject(text)) } catch (_: Exception) {} }
    }

    private fun handleControlSignal(msg: JSONObject) {
        when (msg.optString("type")) {
            "screen" -> {
                val w = msg.optInt("width"); val h = msg.optInt("height")
                if (w > 0 && h > 0) videoAspect = w.toFloat() / h.toFloat()
            }
            "touch" -> {
                if (role != "host" || !approved) return
                val arr = msg.optJSONArray("points") ?: return
                val points = ArrayList<Pair<Float, Float>>(arr.length())
                for (i in 0 until arr.length()) {
                    val p = arr.optJSONArray(i) ?: continue
                    points.add(Pair(p.optDouble(0).toFloat(), p.optDouble(1).toFloat()))
                }
                if (points.isEmpty()) return
                val applied = RemoteTouchService.dispatch(points, msg.optLong("duration", 60L))
                if (!applied && ::status.isInitialized) status("Toque não aplicado: ative o controle remoto em Acessibilidade.")
            }
        }
    }

    private fun addTouchPoint(v: View, ev: MotionEvent) {
        val vw = v.width.toFloat(); val vh = v.height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val aspect = if (videoAspect > 0f) videoAspect else 16f / 9f
        val dispW: Float; val dispH: Float
        if (vw / vh > aspect) { dispH = vh; dispW = vh * aspect } else { dispW = vw; dispH = vw / aspect }
        val offX = (vw - dispW) / 2f; val offY = (vh - dispH) / 2f
        val nx = ((ev.x - offX) / dispW).coerceIn(0f, 1f)
        val ny = ((ev.y - offY) / dispH).coerceIn(0f, 1f)
        touchPoints.add(Pair(nx, ny))
    }

    private fun sendGesture() {
        if (touchPoints.isEmpty()) return
        val arr = JSONArray()
        touchPoints.forEach { arr.put(JSONArray().put(it.first.toDouble()).put(it.second.toDouble())) }
        val duration = (System.currentTimeMillis() - touchStartMs).coerceIn(40L, 5000L)
        sendControl(JSONObject().put("type", "touch").put("points", arr).put("duration", duration))
        touchPoints.clear()
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        try {
            val serviceIntent = Intent(this, ProjectionForegroundService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        } catch (e: Exception) {
            status("Não foi possível iniciar o serviço de compartilhamento: ${e.message}")
            closeSession(); return
        }
        initializeRtc(); initPeer()
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCapturer = ScreenCapturerAndroid(data, object : android.media.projection.MediaProjection.Callback() {
            override fun onStop() { runOnUiThread { status("A captura de tela foi interrompida.") } }
        })
        videoSource = factory!!.createVideoSource(true)
        val helper = SurfaceTextureHelper.create("C09ScreenCapture", egl!!.eglBaseContext)
        screenCapturer!!.initialize(helper, this, videoSource!!.capturerObserver)
        val dm = resources.displayMetrics
        val screenW = maxOf(dm.widthPixels, dm.heightPixels)
        val screenH = minOf(dm.widthPixels, dm.heightPixels)
        val targetW = 1280
        val targetH = ((targetW.toLong() * screenH / screenW).toInt() / 2 * 2).coerceAtLeast(2)
        screenCapturer!!.startCapture(targetW, targetH, 15)
        localTrack = factory!!.createVideoTrack("C09-screen", videoSource)
        peer!!.addTrack(localTrack, listOf("C09-stream"))
        peer!!.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null) return
                peer!!.setLocalDescription(object : SdpObserverAdapter() {}, desc)
                send(JSONObject().put("type", "offer").put("sdp", desc.description))
                runOnUiThread { status("Enviando tela. Mantenha o C09 aberto durante a sessão.") }
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) { runOnUiThread { status("Falha ao preparar vídeo: $error") } }
            override fun onSetFailure(error: String?) {}
        }, MediaConstraints())
    }

    private fun receiveOffer(sdp: String) {
        initPeer()
        val desc = SessionDescription(SessionDescription.Type.OFFER, sdp)
        peer!!.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() {
                remoteDescriptionSet = true
                flushPendingIce()
                peer!!.createAnswer(object : SdpObserverAdapter() {
                    override fun onCreateSuccess(answer: SessionDescription?) {
                        if (answer == null) return
                        peer!!.setLocalDescription(object : SdpObserverAdapter() {}, answer)
                        send(JSONObject().put("type", "answer").put("sdp", answer.description))
                    }
                }, MediaConstraints())
            }
        }, desc)
    }

    private fun receiveAnswer(sdp: String) {
        peer?.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() { remoteDescriptionSet = true; flushPendingIce() }
        }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
    }

    private fun addIce(obj: JSONObject?) {
        if (obj == null) return
        val candidate = IceCandidate(obj.optString("sdpMid"), obj.optInt("sdpMLineIndex"), obj.optString("candidate"))
        if (!remoteDescriptionSet || peer == null) pendingIce.add(candidate)
        else peer?.addIceCandidate(candidate)
    }

    private fun flushPendingIce() {
        val queued = pendingIce.toList()
        pendingIce.clear()
        queued.forEach { peer?.addIceCandidate(it) }
    }

    private fun closeSession() {
        approved = false
        remoteDescriptionSet = false
        pendingIce.clear()
        touchPoints.clear()
        try { send(JSONObject().put("type", "disconnect")); ws?.close() } catch (_: Exception) {}
        ws = null
        try { controlChannel?.unregisterObserver(); controlChannel?.close(); controlChannel?.dispose() } catch (_: Exception) {}
        controlChannel = null
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        try { stopService(Intent(this, ProjectionForegroundService::class.java)) } catch (_: Exception) {}
        screenCapturer?.dispose(); screenCapturer = null
        localTrack?.dispose(); localTrack = null
        videoSource?.dispose(); videoSource = null
        peer?.close(); peer?.dispose(); peer = null
        remoteRenderer?.release(); remoteRenderer = null
        factory?.dispose(); factory = null
        egl?.release(); egl = null
        pin = ""; role = ""
    }

    override fun onDestroy() { closeSession(); super.onDestroy() }
    private fun status(s: String) { if (::status.isInitialized) status.text = s }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(3), dp(3), dp(3), dp(3))
    }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 14f; setTextColor(Color.BLACK)
        background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 0f; setStroke(dp(1), Color.WHITE) }
        minHeight = dp(42); setOnClickListener { action() }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp() = LinearLayout.LayoutParams(-1, -2)
    private fun lpTop() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
}

private open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}