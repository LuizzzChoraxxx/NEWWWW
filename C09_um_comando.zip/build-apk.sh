#!/usr/bin/env bash
set -Eeuo pipefail

# One-command C09 debug APK builder for Linux/Codespaces.
# Run from anywhere inside the extracted project: bash build-apk.sh

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

fail() { echo "ERRO: $*" >&2; exit 1; }
command -v java >/dev/null 2>&1 || fail "Java não encontrado. Use um ambiente com JDK 17 (por exemplo, GitHub Codespaces)."
command -v curl >/dev/null 2>&1 || command -v wget >/dev/null 2>&1 || fail "Instale curl ou wget e tente novamente."
command -v unzip >/dev/null 2>&1 || fail "O comando unzip não está instalado."

JAVA_MAJOR="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
[[ "${JAVA_MAJOR:-0}" -ge 17 ]] || fail "É necessário Java 17 ou superior; encontrado: ${JAVA_MAJOR:-desconhecido}."

fetch() {
  if command -v curl >/dev/null 2>&1; then curl -fL --retry 3 --retry-delay 2 "$1" -o "$2";
  else wget -O "$2" "$1"; fi
}

TOOLS="$HOME/.cache/c09-build-tools"
SDK_ROOT="$HOME/android-sdk"
mkdir -p "$TOOLS" "$SDK_ROOT/cmdline-tools"

# Install official Android command-line tools only when missing.
if [[ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]]; then
  echo "[1/4] Baixando ferramentas oficiais do Android..."
  CMD_ZIP="$TOOLS/android-commandlinetools.zip"
  fetch "https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip" "$CMD_ZIP"
  unzip -tq "$CMD_ZIP" >/dev/null || fail "O download das ferramentas Android está incompleto. Execute o script novamente."
  TMP_TOOLS="$TOOLS/android-cmdline-extract"
  rm -rf "$TMP_TOOLS"
  mkdir -p "$TMP_TOOLS"
  unzip -q "$CMD_ZIP" -d "$TMP_TOOLS"
  [[ -x "$TMP_TOOLS/cmdline-tools/bin/sdkmanager" ]] || fail "O pacote baixado não contém sdkmanager no caminho esperado."
  rm -rf "$SDK_ROOT/cmdline-tools/latest"
  mv "$TMP_TOOLS/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
  rm -rf "$TMP_TOOLS"
fi

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

# Use a Gradle version compatible with Android Gradle Plugin 8.7.x.
GRADLE_HOME="$TOOLS/gradle-8.9"
if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
  echo "[2/4] Baixando Gradle 8.9..."
  GRADLE_ZIP="$TOOLS/gradle-8.9-bin.zip"
  fetch "https://services.gradle.org/distributions/gradle-8.9-bin.zip" "$GRADLE_ZIP"
  unzip -tq "$GRADLE_ZIP" >/dev/null || fail "O download do Gradle está incompleto. Execute o script novamente."
  unzip -q -o "$GRADLE_ZIP" -d "$TOOLS"
fi

SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
echo "[3/4] Instalando componentes Android (licenças, plataforma 35 e build-tools 35.0.0)..."
set +o pipefail
yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1 || true
set -o pipefail
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

# local.properties is machine-specific and ignored by git.
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > "$ROOT/local.properties"

echo "[4/4] Compilando C09..."
"$GRADLE_HOME/bin/gradle" --no-daemon --stacktrace :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || fail "A compilação terminou sem gerar o APK esperado."
echo
echo "SUCESSO: APK gerado em: $APK"
echo "Você pode baixar app/build/outputs/apk/debug/app-debug.apk pelo explorador de arquivos do Codespaces."
