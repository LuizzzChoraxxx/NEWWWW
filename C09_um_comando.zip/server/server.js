const http = require("http");
const { WebSocketServer } = require("ws");
const crypto = require("crypto");

const PORT = process.env.PORT || 8080;
const rooms = new Map(); // pin -> { host, client, expiresAt }
const server = http.createServer((req, res) => {
  res.writeHead(200, { "content-type": "application/json" });
  res.end(JSON.stringify({ ok: true, service: "CONECTA signaling base" }));
});
const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}
function cleanExpired() {
  const now = Date.now();
  for (const [pin, room] of rooms) {
    if (room.expiresAt < now) {
      send(room.host, { type: "expired" });
      send(room.client, { type: "expired" });
      rooms.delete(pin);
    }
  }
}
setInterval(cleanExpired, 5000).unref();

wss.on("connection", (ws) => {
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });
  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws, { type: "error", message: "invalid_json" }); }

    if (msg.type === "create") {
      cleanExpired();
      let pin;
      for (let i = 0; i < 20; i++) {
        const candidate = String(1000 + crypto.randomInt(0, 9000));
        if (!rooms.has(candidate)) { pin = candidate; break; }
      }
      if (!pin) return send(ws, { type: "error", message: "try_again" });
      rooms.set(pin, { host: ws, client: null, expiresAt: Date.now() + 120000 });
      ws.conectaRole = "host"; ws.conectaPin = pin;
      send(ws, { type: "created", pin, expiresIn: 120 });
      return;
    }

    if (msg.type === "join") {
      const pin = String(msg.pin || "");
      const room = rooms.get(pin);
      if (!/^\d{4}$/.test(pin) || !room || room.expiresAt < Date.now() || room.client) {
        return send(ws, { type: "error", message: "invalid_or_expired_pin" });
      }
      room.client = ws;
      ws.conectaRole = "client"; ws.conectaPin = pin;
      send(ws, { type: "joined", message: "Waiting for host approval" });
      send(room.host, { type: "join_request" });
      return;
    }

    // Relay WebRTC signaling only within the room; this base does not implement media.
    const pin = ws.conectaPin;
    const room = pin && rooms.get(pin);
    if (!room || (ws !== room.host && ws !== room.client)) {
      return send(ws, { type: "error", message: "not_in_room" });
    }
    if (msg.type === "approve") {
      if (ws !== room.host || !room.client) return send(ws, { type: "error", message: "approval_not_allowed" });
      room.expiresAt = Date.now() + 60 * 60 * 1000;
      send(room.client, { type: "approved" });
      send(room.host, { type: "approved" });
      return;
    }
    if (msg.type === "disconnect") {
      send(room.host, { type: "disconnected" });
      send(room.client, { type: "disconnected" });
      rooms.delete(pin);
      return;
    }
    if (["offer", "answer", "ice"].includes(msg.type)) {
      if (msg.type === "offer" && ws !== room.host) return send(ws, { type: "error", message: "invalid_sender" });
      if (msg.type === "answer" && ws !== room.client) return send(ws, { type: "error", message: "invalid_sender" });
      send(ws === room.host ? room.client : room.host, msg);
    }
  });
  ws.on("close", () => {
    const pin = ws.conectaPin;
    const room = pin && rooms.get(pin);
    if (room) {
      send(room.host, { type: "peer_disconnected" });
      send(room.client, { type: "peer_disconnected" });
      rooms.delete(pin);
    }
  });
});
server.listen(PORT, () => console.log(`CONECTA signaling base listening on ${PORT}`));