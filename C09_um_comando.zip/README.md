# C09 — transmissão de tela e controle remoto autorizado (Android)

Interface simples: paisagem, fundo preto, botões brancos retangulares, sem fotos e nome C09.

## O que está implementado

- Pareamento com código temporário via servidor WebSocket.
- Pedido de conexão separado da autorização no aparelho que compartilha.
- Pedido explícito de permissão de captura de tela do Android.
- Captura e envio de vídeo via WebRTC e exibição do vídeo no aparelho que assiste.
- Sinalização WebRTC de oferta, resposta e candidatos ICE pelo servidor.
- Canal de dados WebRTC (`c09-control`) para o controle remoto.
- **Controle remoto de toques**: quem assiste toca/arrasta sobre o vídeo; o C09 envia os
  gestos (coordenadas normalizadas e duração) pelo canal de dados e o aparelho que
  compartilha aplica via `AccessibilityService` (`dispatchGesture`).
- O controle remoto só funciona com o serviço de Acessibilidade do C09 **ativado pelo
  usuário** (Ajustes → Acessibilidade) e apenas durante uma sessão aprovada.
- Notificação persistente enquanto o aparelho compartilha a tela e botão de desconexão.

## Como usar o controle remoto

1. No aparelho que **compartilha**: tela principal → "Compartilhar minha tela" → informe o
   servidor `wss://` → "Permitir controle remoto (Acessibilidade)" → ative o **C09** em
   Ajustes → Acessibilidade → volte ao C09.
2. Autorize a conexão e a captura de tela quando o Android pedir.
3. No aparelho que **assiste**: toque na tela para tocar no aparelho remoto; arraste para
   rolar/navegar.

O controle remoto é opcional: se a Acessibilidade do C09 estiver desativada, só o vídeo
é transmitido.

## Limites importantes

**Toques e arrastos são aproximados, não em tempo real quadro a quadro.** Cada gesto é
enviado ao soltar o dedo (toque, rolagem/arrasto e toque longo funcionam bem); o gesto é
reproduzido com a duração real, mas não há retorno visual durante o movimento. Só há
suporte a um dedo por vez.

A conexão depende de um servidor de sinalização público configurado por você e de
conectividade WebRTC entre os dois aparelhos. O servidor desta pasta é uma base de
sinalização, não um servidor de vídeo. Para funcionar fora de redes simples, normalmente
será necessário configurar TURN (por exemplo, coturn) e acrescentar suas credenciais à
configuração ICE do app. O servidor precisa ser servido por `wss://` com TLS; não publique
o serviço sem proteção contra abuso.

A pessoa que compartilha precisa aceitar a confirmação de captura de tela do Android e
ativar a Acessibilidade por conta própria. O app não tenta ignorar nem burlar essas
permissões. Encerrar pelo botão do C09 interrompe a sessão e o controle remoto.

**Aviso de segurança:** um serviço de Acessibilidade capaz de injetar gestos é sensível.
Mantenha o pareamento, a autorização explícita e o `wss://` protegido; adicione
autenticação e limitação de tentativas antes de qualquer uso público. O PIN de 4 dígitos é
temporário e, sozinho, não é segurança suficiente.

## Estado da compilação

O código-fonte está completo, mas **este ambiente não compila o APK**. Compile pelo
workflow do GitHub Actions ou no Android Studio; valide em aparelhos reais antes de usar.

## Como preparar o servidor

1. Publique `server/server.js` num serviço Node.js que permita WebSocket e forneça TLS/WSS.
2. Instale `npm install` dentro de `server/` (pacote `ws`).
3. Configure a variável `PORT` se a plataforma exigir.
4. Copie o endereço `wss://...` e informe-o no campo de servidor dentro do C09 em ambos os aparelhos.
5. Para uso público, adicione autenticação, limitação de tentativas e proteção antiabuso.

## Gerar APK na nuvem

1. Crie um repositório no GitHub: https://github.com/.
2. Envie o conteúdo da pasta `C09/` para a raiz do repositório.
3. Abra **Actions** e execute **Build C09 APK** (ou aguarde o workflow de push).
4. Se a compilação passar, baixe o artefato **C09-apk-debug**.
5. Extraia o ZIP e localize `app-debug.apk`.

É um APK de depuração, não uma versão assinada para publicação.

## Compilar com um comando (Codespaces/Linux)

1. Extraia o conteúdo desta pasta na raiz do seu ambiente de desenvolvimento.
2. Abra o terminal na pasta do projeto e execute **um único comando**:

```bash
bash build-apk.sh
```

O script configura as ferramentas Android oficiais, instala a plataforma Android 35 e
o Build Tools 35.0.0, usa Gradle 8.9 (compatível com o Android Gradle Plugin 8.7.3)
e tenta gerar o APK de depuração. É necessário Java 17+, conexão com a internet e espaço livre para baixar as ferramentas. O primeiro uso pode demorar. Se falhar, o script para
na etapa que deu erro e mostra a mensagem original.

O APK, se a compilação for bem-sucedida, ficará em
`app/build/outputs/apk/debug/app-debug.apk`. Este é um APK debug para testes, não um
APK de release assinado para publicação. Nenhum script pode garantir ausência total de
bugs; teste o app em aparelhos reais.

## Compilação local oficial

Android Studio: https://developer.android.com/studio